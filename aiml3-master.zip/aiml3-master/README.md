# 人工智能模块AIML Python3.5版本
`Copyright © 2016 Rain. All Rights Reserved. `

```
支持(Support)：Python3，中文模式，API插件
维护(Current Maintainer)：decalogue (1044908508@qq.com)
```

> * 支持中文规则
> * API 插件支持
> * 使用半角标点

-------
作者 Rain [@Decalogue][1]

[1]: https://www.decalogue.cn
